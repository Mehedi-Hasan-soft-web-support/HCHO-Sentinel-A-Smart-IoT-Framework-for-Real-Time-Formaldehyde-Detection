/* ===========================================================================
 *  HCHO-Sentinel node  |  firmware 3.0.0
 *  MS1100 VOC-HCHO sensor  +  ESP32 DevKit v1  ->  Supabase
 *  ---------------------------------------------------------------------------
 *  Author : Md. Mehedi Hasan (232-15-497), Daffodil International University
 *  Board  : ESP32 Dev Module  |  Arduino-ESP32 core 2.0.x or 3.x
 *
 *  ROLE OF THIS FIRMWARE
 *    Write devices and live_reading. That is all.
 *    It NEVER stores research data. The dashboard owns samples and readings,
 *    and only writes them when you pick a class and press Save.
 *
 *  LIBRARIES
 *    ArduinoJson v6.x  (Benoit Blanchon)
 *    Adafruit SSD1306 + Adafruit GFX   (only if USE_OLED)
 *
 *  ---------------------------------------------------------------------------
 *  WIRING
 *    MS1100 VCC  -> 5V (VIN)          heater needs the full 5V rail
 *    MS1100 GND  -> GND               COMMON GROUND, mandatory
 *    MS1100 AOUT -> R1 10k -> GPIO34, junction -> R2 10k -> GND
 *    MS1100 DOUT -> GPIO35            module's own comparator, optional
 *    100 nF from GPIO34 to GND        steadies the ADC sample
 *
 *    Buzzer GPIO25   Status LED GPIO2   Alarm LED GPIO26 via 220R
 *
 *    GPIO34/35 are input-only ADC1 pins. Never analogRead an ADC2 pin while
 *    WiFi is on; the radio owns ADC2 and returns garbage.
 *
 *  ---------------------------------------------------------------------------
 *  BRING-UP ORDER
 *    1. Run schema.sql in Supabase.
 *    2. Put the SAME project URL and anon key in secrets.h and in the
 *       dashboard's CONFIG block. Different projects is the number one reason
 *       a dashboard shows nothing.
 *    3. Flash. Type  raw  and confirm the adc column MOVES.
 *       Pinned at 0 or 4095 means the wiring is broken. Stop and fix it.
 *    4. Wait out the warm-up in clean air, then type  cal.
 *    5. Open the dashboard. The dot should go green within a few seconds.
 *
 *  MEASUREMENT ROUTINE (per capture)
 *    - empty chamber, type  base , copy the printed ppm into the dashboard
 *      Baseline field
 *    - put the fish in, seal, wait for the badge to read "stable"
 *    - pick the class, fill the metadata, press Save
 *
 *  SERIAL COMMANDS:  cal | info | raw | base | wipe | live
 * ===========================================================================
 */

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <time.h>

#include "secrets.h"

#define USE_OLED  0

// ===========================================================================
//  1. CONFIGURATION
// ===========================================================================
const char* WIFI_SSID     = SECRET_WIFI_SSID;
const char* WIFI_PASSWORD = SECRET_WIFI_PASSWORD;
const char* SUPABASE_URL  = SECRET_SUPABASE_URL;
const char* SUPABASE_ANON = SECRET_SUPABASE_ANON;

/*  Must be byte-for-byte identical to DEVICE_ID in the dashboard CONFIG block
 *  and to devices.device_id in Supabase. A silent mismatch means rows insert
 *  fine and nothing ever renders.
 */
#define DEVICE_ID   "hcho-node-01"
#define FW_VERSION  "3.0.0"

// ---- Timing ---------------------------------------------------------------
const uint32_t WARMUP_MS     = 180000;  // 3 min before readings count
const uint32_t SAMPLE_MS     = 1000;    // local read cadence
/*  LIVE_MS must stay near 1 s. The dashboard needs MIN_POINTS (10) inside its
 *  shortest capture window (20 s). At a 3 s push rate that window only ever
 *  holds ~6 points and the Save button never enables.
 */
const uint32_t LIVE_MS       = 1000;
const uint32_t WIFI_RETRY_MS = 15000;
const uint32_t NTP_RETRY_MS  = 60000;
const uint32_t REG_RETRY_MS  = 60000;

// ---- Pins -----------------------------------------------------------------
const int PIN_AOUT = 34, PIN_DOUT = 35;
const int PIN_BUZZER = 25, PIN_LED_STAT = 2, PIN_LED_ALARM = 26;

// ---- ADC ------------------------------------------------------------------
const float ADC_VREF = 3.30f;
const int   ADC_MAX  = 4095;

/*  Validity window. A disconnected AOUT reads near 0, a shorted one near full
 *  scale. Neither is a measurement, and neither may reach the dashboard.
 */
const int     ADC_MIN_VALID = 25;
const int     ADC_MAX_VALID = ADC_MAX - 25;
const uint8_t STUCK_LIMIT   = 12;   // identical counts in a row = dead pin

// ---- Sensor front-end -----------------------------------------------------
#define SENSOR_5V 1
#if SENSOR_5V
  const float VC_VOLT      = 5.0f;
  const float DIVIDER_GAIN = 2.0f;
  /*  Module load resistor (usually 10k) is loaded by your external 10k/10k
   *  divider, another 20k to ground. Effective RL = 10k || 20k = 6.67k.
   *  If your module is marked 102 instead of 103, use 0.952.
   *  This cancels in the Rs/R0 ratio, so ppm is unaffected either way.
   */
  const float RL_KOHM      = 6.67f;
#else
  const float VC_VOLT      = 3.30f;
  const float DIVIDER_GAIN = 1.0f;
  const float RL_KOHM      = 10.0f;
#endif

/*  MS1100 power law, ppm = A * (Rs/R0)^B, digitised from the datasheet HCHO
 *  curve. The SHAPE is right, the ABSOLUTE SCALE is sensor-specific.
 *  For the fish study, model on ratio or on ppm/baseline, not raw ppm.
 */
const float CURVE_A = 0.6103f;
const float CURVE_B = -2.2926f;

/*  R0 is a reference resistance, not the resistance you happen to measure in
 *  fresh air. Storing raw clean-air Rs would make ratio = 1, and the curve
 *  returns 0.61 ppm there: a permanent false alarm. Anchoring at 4.4 puts
 *  clean air near 0.02 ppm and the WHO limit at ratio ~2.4.
 */
const float CLEAN_AIR_RATIO = 4.4f;

const float PPM_MODERATE = 0.048f;
const float PPM_WARN     = 0.080f;
const float PPM_ALARM    = 0.300f;

// ===========================================================================
//  2. GLOBALS
// ===========================================================================
Preferences prefs;

#if USE_OLED
  #include <Wire.h>
  #include <Adafruit_GFX.h>
  #include <Adafruit_SSD1306.h>
  Adafruit_SSD1306 oled(128, 64, &Wire, -1);
#endif

struct Reading {
  int    adc;
  float  mv, rs, ratio, ppm, mg;
  int8_t level;        // -1 fault, 0 good, 1 moderate, 2 warn, 3 alarm
  bool   ok;
};

struct RawRead { int adc; float mv; bool ok; const char* fault; };

Reading  last;
float    R0 = 0.0f;
bool     calibrated = false, warmedUp = false;
bool     liveEnabled = true, deviceRegistered = false;
uint32_t bootMs = 0, tSample = 0, tLive = 0, tNtp = 0, tReg = 0;
uint32_t liveSeq = 0;
float    ppmEma = 0.0f;
const float EMA_ALPHA = 0.25f;

int     prevAdc = -1;
uint8_t sameCount = 0;

const char* LEVEL_NAME[4] = { "good", "moderate", "warn", "alarm" };
const char* levelName(int8_t l){ return (l < 0 || l > 3) ? "fault" : LEVEL_NAME[l]; }
bool timeValid(){ return time(nullptr) > 1700000000; }

void registerDevice();
void patchDeviceR0();

// ===========================================================================
//  3. SENSOR
// ===========================================================================
RawRead readSensor() {
  RawRead r; r.fault = nullptr;

  const int N = 64;
  uint32_t acc = 0;
  for (int i = 0; i < N; i++) { acc += analogRead(PIN_AOUT); delayMicroseconds(200); }
  float counts = (float)acc / N;
  r.adc = (int)counts;
  r.mv  = (counts / ADC_MAX) * ADC_VREF * DIVIDER_GAIN * 1000.0f;

  if (r.adc < ADC_MIN_VALID) {
    r.ok = false; r.fault = "AOUT near 0 - open circuit, no common ground, or sensor unpowered";
    return r;
  }
  if (r.adc > ADC_MAX_VALID) {
    r.ok = false; r.fault = "AOUT at full scale - shorted to VCC or divider missing";
    return r;
  }

  if (r.adc == prevAdc) { if (sameCount < 255) sameCount++; }
  else                  { sameCount = 0; prevAdc = r.adc; }

  if (sameCount >= STUCK_LIMIT) {
    r.ok = false; r.fault = "ADC frozen on one value - pin not tracking anything live";
    return r;
  }

  r.ok = true;
  return r;
}

float mvToRs(float mv) {
  float v = mv / 1000.0f;
  if (v <= 0.001f || v >= VC_VOLT - 0.001f) return NAN;
  return ((VC_VOLT - v) / v) * RL_KOHM;
}

float ratioToPpm(float ratio) {
  if (ratio <= 0.0f) return 0.0f;
  float ppm = CURVE_A * powf(ratio, CURVE_B);
  if (isnan(ppm) || isinf(ppm)) return 0.0f;
  return constrain(ppm, 0.0f, 30.0f);
}

int8_t classify(float ppm) {
  if (ppm >= PPM_ALARM)    return 3;
  if (ppm >= PPM_WARN)     return 2;
  if (ppm >= PPM_MODERATE) return 1;
  return 0;
}

void calibrateR0() {
  Serial.println(F("\n[CAL] Clean-air calibration. Keep the node in fresh air."));

  RawRead pre = readSensor();
  if (!pre.ok) {
    Serial.printf("[CAL] ABORTED. %s\n", pre.fault);
    Serial.printf("[CAL] adc = %d. Fix the wiring, confirm with 'raw', then retry.\n\n", pre.adc);
    return;
  }

  Serial.println(F("[CAL] Sampling for 30 s ..."));
  float acc = 0, first = 0, lastRs = 0; int n = 0;

  for (int i = 0; i < 30; i++) {
    RawRead r = readSensor();
    if (!r.ok) { Serial.printf("\n[CAL] ABORTED at %d/30. %s\n\n", i + 1, r.fault); return; }
    float rs = mvToRs(r.mv);
    if (isnan(rs)) { Serial.println(F("\n[CAL] ABORTED: Rs out of range.\n")); return; }
    if (i == 0) first = rs;
    lastRs = rs; acc += rs; n++;
    Serial.printf("  %2d/30  adc = %4d   Rs = %.2f kOhm\n", i + 1, r.adc, rs);
    digitalWrite(PIN_LED_STAT, !digitalRead(PIN_LED_STAT));
    delay(1000);
  }
  float rsAir = acc / n;

  float drift = fabsf(lastRs - first) / rsAir * 100.0f;
  if (drift > 3.0f) {
    Serial.printf("[CAL] WARNING: Rs moved %.1f%% during calibration.\n", drift);
    Serial.println(F("[CAL] Not settled. Wait 10-20 min and run 'cal' again."));
  }

  R0 = rsAir / CLEAN_AIR_RATIO;
  calibrated = true;
  prefs.begin("hcho", false); prefs.putFloat("r0", R0); prefs.end();
  Serial.printf("[CAL] Clean-air Rs = %.2f kOhm\n", rsAir);
  Serial.printf("[CAL] Done. R0 = %.2f kOhm stored (anchor %.1f).\n\n", R0, CLEAN_AIR_RATIO);
  patchDeviceR0();
}

// ===========================================================================
//  4. NETWORK
// ===========================================================================
void wifiConnectBlocking() {
  Serial.printf("[WiFi] connecting to %s ", WIFI_SSID);
  WiFi.mode(WIFI_STA); WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) { delay(400); Serial.print('.'); }
  Serial.println(WiFi.status() == WL_CONNECTED
                 ? "  connected: " + WiFi.localIP().toString()
                 : "  FAILED (retrying in background)");
}

// Non-blocking. A blocking reconnect inside the loop would freeze the buzzer
// mid-alarm and stall sampling for 20 s.
void wifiTick() {
  static uint32_t tWifi = 0;
  if (WiFi.status() == WL_CONNECTED) return;
  if (millis() - tWifi < WIFI_RETRY_MS) return;
  tWifi = millis();
  Serial.println(F("[WiFi] reconnecting"));
  WiFi.disconnect();
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

void syncTime() {
  configTime(6 * 3600, 0, "pool.ntp.org", "time.nist.gov");   // Asia/Dhaka, no DST
  Serial.print(F("[NTP] syncing "));
  uint32_t t0 = millis();
  while (!timeValid() && millis() - t0 < 15000) { delay(300); Serial.print('.'); }
  Serial.println(timeValid() ? F("  ok") : F("  TIMEOUT"));
}

void ntpTick() {
  if (timeValid() || WiFi.status() != WL_CONNECTED) return;
  if (millis() - tNtp < NTP_RETRY_MS) return;
  tNtp = millis();
  configTime(6 * 3600, 0, "pool.ntp.org", "time.nist.gov");
}

String isoTime(time_t t) {
  struct tm tmv; localtime_r(&t, &tmv);
  char buf[32];
  strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S+06:00", &tmv);
  return String(buf);
}

int postJson(const String& path, const String& body, const char* prefer, String& respOut) {
  if (WiFi.status() != WL_CONNECTED) return -1;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http;
  if (!http.begin(client, String(SUPABASE_URL) + path)) return -2;
  http.addHeader("apikey", SUPABASE_ANON);
  http.addHeader("Authorization", String("Bearer ") + SUPABASE_ANON);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Prefer", prefer);
  http.setTimeout(10000);
  int code = http.POST(body);
  respOut = (code > 0 && code != 200 && code != 201) ? http.getString() : "";
  http.end();
  return code;
}

void registerDevice() {
  StaticJsonDocument<384> doc;
  doc["device_id"]    = DEVICE_ID;
  doc["sensor_model"] = "MS1100";
  doc["firmware"]     = FW_VERSION;
  doc["warn_ppm"]     = PPM_WARN;
  doc["alarm_ppm"]    = PPM_ALARM;
  if (calibrated) doc["r0_clean_air"] = R0;
  String body; serializeJson(doc, body);

  String resp;
  int code = postJson("/rest/v1/devices?on_conflict=device_id", body,
                      "resolution=merge-duplicates,return=minimal", resp);
  deviceRegistered = (code == 200 || code == 201);
  Serial.printf("[SB ] device upsert -> %d %s\n", code, resp.c_str());
}

void patchDeviceR0() {
  if (WiFi.status() != WL_CONNECTED) return;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http;
  if (!http.begin(client, String(SUPABASE_URL) + "/rest/v1/devices?device_id=eq." + DEVICE_ID)) return;
  http.addHeader("apikey", SUPABASE_ANON);
  http.addHeader("Authorization", String("Bearer ") + SUPABASE_ANON);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Prefer", "return=minimal");
  String body = String("{\"r0_clean_air\":") + String(R0, 3) + "}";
  Serial.printf("[SB ] R0 patch -> %d\n", http.sendRequest("PATCH", body));
  http.end();
}

/*  The only data path. One row per device, upserted on device_id.
 *  updated_at is set by a Postgres trigger, so the dashboard's freshness
 *  check does not depend on the ESP32 clock being right.
 */
bool pushLive() {
  if (WiFi.status() != WL_CONNECTED) return false;

  StaticJsonDocument<768> doc;
  JsonArray arr = doc.to<JsonArray>();
  JsonObject o  = arr.createNestedObject();

  o["device_id"]     = DEVICE_ID;
  o["seq"]           = ++liveSeq;
  if (timeValid()) o["recorded_at"] = isoTime(time(nullptr));
  o["adc_raw"]       = last.adc;
  o["voltage_mv"]    = roundf(last.mv * 10) / 10.0f;
  o["rs_kohm"]       = roundf(last.rs * 100) / 100.0f;
  o["ratio"]         = roundf(last.ratio * 1000) / 1000.0f;
  o["hcho_ppm"]      = roundf(last.ppm * 10000) / 10000.0f;
  o["hcho_mg_m3"]    = roundf(last.mg * 10000) / 10000.0f;
  o["level"]         = levelName(last.level);
  o["sensor_ok"]     = last.ok;
  o["warmed_up"]     = warmedUp;
  o["is_calibrated"] = calibrated;
  o["rssi"]          = WiFi.RSSI();
  o["uptime_s"]      = (uint32_t)(millis() / 1000);
  o["fw"]            = FW_VERSION;

  String body; serializeJson(doc, body);
  String resp;
  int code = postJson("/rest/v1/live_reading?on_conflict=device_id", body,
                      "resolution=merge-duplicates,return=minimal", resp);
  if (code != 200 && code != 201)
    Serial.printf("[SB ] live push -> %d %s\n", code, resp.c_str());
  return (code == 200 || code == 201);
}

// ===========================================================================
//  5. LOCAL FEEDBACK
// ===========================================================================
void updateIndicators(int8_t level) {
  static uint32_t tBeep = 0;
  static bool beepOn = false;

  // A wiring fault is not a gas alarm and must not sound like one.
  if (level < 0) {
    digitalWrite(PIN_LED_ALARM, HIGH);
    digitalWrite(PIN_BUZZER, LOW);
    beepOn = false;
    return;
  }

  digitalWrite(PIN_LED_ALARM, level >= 2 ? HIGH : LOW);
  if (level == 3) {
    if (millis() - tBeep > 200) { beepOn = !beepOn; digitalWrite(PIN_BUZZER, beepOn); tBeep = millis(); }
  } else if (level == 2) {
    if (millis() - tBeep > 900) { beepOn = !beepOn; digitalWrite(PIN_BUZZER, beepOn); tBeep = millis(); }
  } else {
    digitalWrite(PIN_BUZZER, LOW); beepOn = false;
  }
}

// ===========================================================================
//  6. SERIAL
// ===========================================================================
void printInfo() {
  Serial.println(F("\n---------------- HCHO-Sentinel ----------------"));
  Serial.printf("Device      : %s  (fw %s)\n", DEVICE_ID, FW_VERSION);
  Serial.printf("WiFi        : %s  RSSI %d dBm\n",
                WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString().c_str() : "offline",
                WiFi.RSSI());
  Serial.printf("Registered  : %s\n", deviceRegistered ? "yes" : "no");
  Serial.printf("Clock       : %s\n", timeValid() ? "valid" : "INVALID");
  Serial.printf("Sensor      : %s\n", last.ok ? "ok" : "FAULT");
  Serial.printf("Calibrated  : %s   R0 = %.2f kOhm\n", calibrated ? "yes" : "NO - run 'cal'", R0);
  Serial.printf("Warmed up   : %s\n", warmedUp ? "yes" : "no");
  Serial.printf("Live push   : %s   seq = %lu\n", liveEnabled ? "on" : "off", (unsigned long)liveSeq);
  Serial.printf("Last        : %.4f ppm  ratio %.3f  adc %d  (%s)\n",
                last.ppm, last.ratio, last.adc, levelName(last.level));
  Serial.println(F("Commands    : cal | info | raw | base | wipe | live"));
  Serial.println(F("-----------------------------------------------\n"));
}

/*  Empty-chamber reference. Take one before EVERY capture and type the number
 *  into the dashboard's Baseline field. Nothing compensates for drift
 *  automatically, so this is what lets you divide it out later.
 */
void printBaseline() {
  if (!last.ok)      { Serial.println(F("[BASE] sensor fault, no baseline taken.")); return; }
  if (!calibrated)   { Serial.println(F("[BASE] not calibrated. Run 'cal' first.")); return; }
  if (!warmedUp)     { Serial.println(F("[BASE] still warming up.")); return; }

  Serial.println(F("\n[BASE] Averaging 15 s with the chamber EMPTY ..."));
  float acc = 0; int n = 0;
  for (int i = 0; i < 15; i++) {
    RawRead r = readSensor();
    if (!r.ok) { Serial.printf("[BASE] ABORTED. %s\n\n", r.fault); return; }
    float rs = mvToRs(r.mv);
    if (!isnan(rs) && R0 > 0.1f) { acc += ratioToPpm(rs / R0); n++; }
    delay(1000);
  }
  if (!n) { Serial.println(F("[BASE] no valid points.\n")); return; }
  Serial.printf("[BASE] baseline = %.4f ppm   <-- type this into the dashboard\n\n", acc / n);
}

void handleSerial() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n');
  cmd.trim(); cmd.toLowerCase();
  if (!cmd.length()) return;

  if      (cmd == "cal")  calibrateR0();
  else if (cmd == "info") printInfo();
  else if (cmd == "base") printBaseline();
  else if (cmd == "live") {
    liveEnabled = !liveEnabled;
    Serial.printf("[RUN] live push %s\n", liveEnabled ? "ON" : "OFF");
  }
  else if (cmd == "raw") {
    Serial.println(F("Watch the adc column. If it does not move, the pin is dead."));
    for (int i = 0; i < 20; i++) {
      RawRead r = readSensor();
      float rs = r.ok ? mvToRs(r.mv) : NAN;
      Serial.printf("adc=%4d  mv=%7.1f  Rs=%8.2f  ratio=%6.3f  %s\n",
                    r.adc, r.mv, rs, (r.ok && R0 > 0.1f) ? rs / R0 : 0.0f,
                    r.ok ? "ok" : r.fault);
      delay(500);
    }
  }
  else if (cmd == "wipe") {
    prefs.begin("hcho", false); prefs.clear(); prefs.end();
    R0 = 0; calibrated = false; ppmEma = 0;
    Serial.println(F("[NVS] calibration erased. Run 'cal' after warm-up."));
  }
  else Serial.println(F("? try: cal | info | raw | base | wipe | live"));
}

// ===========================================================================
//  7. SETUP / LOOP
// ===========================================================================
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println(F("\n\n=== HCHO-Sentinel node 3.0.0 : MS1100 + ESP32 ==="));

  pinMode(PIN_DOUT, INPUT);
  pinMode(PIN_BUZZER, OUTPUT);    digitalWrite(PIN_BUZZER, LOW);
  pinMode(PIN_LED_STAT, OUTPUT);
  pinMode(PIN_LED_ALARM, OUTPUT); digitalWrite(PIN_LED_ALARM, LOW);

  analogReadResolution(12);
  analogSetPinAttenuation(PIN_AOUT, ADC_11db);

  memset(&last, 0, sizeof(last));
  last.ok = false; last.level = -1;

  prefs.begin("hcho", true);
  R0 = prefs.getFloat("r0", 0.0f);
  prefs.end();
  calibrated = (R0 > 0.1f);
  Serial.printf("[NVS] R0 = %.2f kOhm  (%s)\n", R0,
                calibrated ? "loaded" : "not calibrated - run 'cal' after warm-up");

  wifiConnectBlocking();
  syncTime();
  registerDevice();

  bootMs = tSample = tLive = tNtp = tReg = millis();
  printInfo();
  Serial.printf("[RUN] warming up for %lu s ...\n", (unsigned long)(WARMUP_MS / 1000));
}

void loop() {
  handleSerial();
  wifiTick();
  ntpTick();

  if (!warmedUp && millis() - bootMs >= WARMUP_MS) {
    warmedUp = true;
    Serial.println(F("[RUN] warm-up complete, readings are now valid."));
  }

  // ---------------- sample -------------------------------------------------
  if (millis() - tSample >= SAMPLE_MS) {
    tSample = millis();

    RawRead r = readSensor();
    last.adc = r.adc;
    last.mv  = r.mv;
    last.ok  = r.ok;

    if (!r.ok) {
      // Do not fabricate a measurement. The dashboard reads sensor_ok.
      last.rs = last.ratio = last.ppm = last.mg = 0.0f;
      last.level = -1;
      ppmEma = 0.0f;
      updateIndicators(-1);
      digitalWrite(PIN_LED_STAT, LOW);
      Serial.printf("[ERR] SENSOR FAULT  adc=%d  %s\n", r.adc, r.fault);
    } else {
      float rs    = mvToRs(r.mv);
      float ratio = (R0 > 0.1f) ? rs / R0 : 0.0f;
      float ppm   = calibrated ? ratioToPpm(ratio) : 0.0f;

      ppmEma = (ppmEma <= 0) ? ppm : (EMA_ALPHA * ppm + (1 - EMA_ALPHA) * ppmEma);

      last.rs    = rs;
      last.ratio = ratio;
      last.ppm   = ppmEma;
      last.mg    = ppmEma * 1.228f;     // HCHO, MW 30.03, 25 C 1 atm
      last.level = (warmedUp && calibrated) ? classify(ppmEma) : 0;

      updateIndicators(last.level);
      digitalWrite(PIN_LED_STAT, WiFi.status() == WL_CONNECTED);

      bool doutTrip = (digitalRead(PIN_DOUT) == LOW);
      Serial.printf("[%s] %.4f ppm | adc %4d | Rs %.1fk | ratio %.3f | %s | DOUT %s%s\n",
                    warmedUp ? "OK " : "WRM", last.ppm, last.adc, rs, ratio,
                    levelName(last.level), doutTrip ? "TRIP" : "idle",
                    calibrated ? "" : "  (uncalibrated)");
    }
  }

  // ---------------- live push ----------------------------------------------
  if (liveEnabled && millis() - tLive >= LIVE_MS) {
    tLive = millis();
    pushLive();
  }

  // ---------------- device registration retry ------------------------------
  // If the node booted with WiFi down, the devices row was never written.
  if (!deviceRegistered && WiFi.status() == WL_CONNECTED && millis() - tReg >= REG_RETRY_MS) {
    tReg = millis();
    registerDevice();
  }
}
