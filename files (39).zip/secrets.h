/* ===========================================================================
 *  secrets.h  |  HCHO-Sentinel credentials
 *  ---------------------------------------------------------------------------
 *  ADD TO .gitignore. Never commit this file.
 *
 *  CRITICAL: SECRET_SUPABASE_URL and SECRET_SUPABASE_ANON below must be the
 *  SAME project as SUPABASE_URL / SUPABASE_ANON in the dashboard's CONFIG
 *  block. Two different projects is the single most common reason a dashboard
 *  sits at "no data" forever while the serial monitor looks perfectly healthy.
 * ===========================================================================
 */
#pragma once

#define SECRET_WIFI_SSID      "Me"
#define SECRET_WIFI_PASSWORD  "CHANGE_ME"

// Project used by the dashboard you sent
#define SECRET_SUPABASE_URL   "https://wpnxyrdmmjttusmnurdr.supabase.co"

#define SECRET_SUPABASE_ANON \
  "PASTE_THE_SAME_ANON_KEY_THE_DASHBOARD_USES"
