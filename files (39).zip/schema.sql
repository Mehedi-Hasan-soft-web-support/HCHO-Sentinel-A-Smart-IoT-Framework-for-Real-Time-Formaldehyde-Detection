-- ===========================================================================
--  HCHO-Sentinel  |  complete Supabase schema
--  Matches dashboard index.html and firmware 3.0.0
--  Run this whole file once, top to bottom, in the SQL editor.
--  Safe to re-run.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. devices  -  one row per node, upserted by the ESP32 on boot
-- ---------------------------------------------------------------------------
create table if not exists public.devices (
  device_id     text primary key,
  sensor_model  text,
  firmware      text,
  warn_ppm      real,
  alarm_ppm     real,
  r0_clean_air  real,
  location      text,
  notes         text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- 2. live_reading  -  SINGULAR. Exactly one row per device, overwritten
--    about once a second. This is scratch state for the dashboard.
--    Nothing here is research data. Never export it.
-- ---------------------------------------------------------------------------
create table if not exists public.live_reading (
  device_id      text primary key,
  seq            bigint,        -- monotonic counter, dashboard dedupes on it
  recorded_at    timestamptz,   -- ESP32 clock
  adc_raw        integer,
  voltage_mv     real,
  rs_kohm        real,
  ratio          real,
  hcho_ppm       real,
  hcho_mg_m3     real,
  level          text,
  sensor_ok      boolean default true,
  warmed_up      boolean default false,
  is_calibrated  boolean default false,
  rssi           integer,
  uptime_s       integer,
  fw             text,
  updated_at     timestamptz not null default now()   -- server clock, trusted
);

-- ---------------------------------------------------------------------------
-- 3. samples  -  ONE ROW PER CAPTURE. Written only by the dashboard Save
--    button. This is your dataset. Each row is an aggregate over a capture
--    window, with the metadata you typed in beside it.
-- ---------------------------------------------------------------------------
create table if not exists public.samples (
  id            bigint generated always as identity primary key,
  device_id     text not null,
  label         text not null,
  sample_no     integer not null,

  n_readings    integer not null,
  ppm_mean      real,
  ppm_sd        real,
  ppm_min       real,
  ppm_max       real,
  ratio_mean    real,
  rs_mean       real,

  temp_mean     real,     -- typed by hand, no DHT fitted
  rh_mean       real,

  fish_species  text,
  fish_mass_g   real,
  formalin_pct  real,
  chamber_ml    real,
  baseline_ppm  real,
  notes         text,

  created_at    timestamptz not null default now(),

  constraint samples_label_ck check (label in (
    'Fresh_Fish',
    'Formalin_6h','Formalin_12h','Formalin_24h',
    -- time-matched untreated controls. Add the buttons to the dashboard when
    -- your supervisor agrees to the control arm; the schema already allows it.
    'Control_6h','Control_12h','Control_24h'
  )),
  constraint samples_unique_no unique (device_id, label, sample_no)
);

create index if not exists samples_label_idx on public.samples (label, sample_no);

-- ---------------------------------------------------------------------------
-- 4. readings  -  RAW per-second points behind each sample.
--    NOTE: in this design 'readings' means raw trace, not labelled capture.
--    Every row belongs to a samples row via sample_id.
-- ---------------------------------------------------------------------------
create table if not exists public.readings (
  id           bigint generated always as identity primary key,
  sample_id    bigint not null references public.samples (id) on delete cascade,
  device_id    text not null,
  label        text not null,
  sample_no    integer not null,
  recorded_at  timestamptz not null,
  t_offset_ms  integer,
  hcho_ppm     real,
  ratio        real,
  rs_kohm      real,
  adc_raw      integer
);

create index if not exists readings_sample_idx on public.readings (sample_id, t_offset_ms);

-- ---------------------------------------------------------------------------
-- 5. updated_at triggers
-- ---------------------------------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists live_reading_touch on public.live_reading;
create trigger live_reading_touch
  before insert or update on public.live_reading
  for each row execute function public.touch_updated_at();

drop trigger if exists devices_touch on public.devices;
create trigger devices_touch
  before insert or update on public.devices
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------------
-- 6. Row level security
--    The anon key sits in the firmware AND in the dashboard, so treat it as
--    public. These policies suit a private project during data collection.
--    Note there is no delete policy: a saved sample cannot be removed from
--    the browser. That is deliberate.
-- ---------------------------------------------------------------------------
alter table public.devices      enable row level security;
alter table public.live_reading enable row level security;
alter table public.samples      enable row level security;
alter table public.readings     enable row level security;

drop policy if exists devices_all  on public.devices;
create policy devices_all  on public.devices      for all    to anon using (true) with check (true);

drop policy if exists live_all     on public.live_reading;
create policy live_all     on public.live_reading for all    to anon using (true) with check (true);

drop policy if exists samples_read on public.samples;
create policy samples_read on public.samples      for select to anon using (true);
drop policy if exists samples_ins  on public.samples;
create policy samples_ins  on public.samples      for insert to anon with check (true);

drop policy if exists readings_read on public.readings;
create policy readings_read on public.readings    for select to anon using (true);
drop policy if exists readings_ins  on public.readings;
create policy readings_ins  on public.readings    for insert to anon with check (true);

-- Realtime for the live panel
do $$
begin
  alter publication supabase_realtime add table public.live_reading;
exception when duplicate_object then null;
end $$;

-- ---------------------------------------------------------------------------
-- 7. v_label_counts  -  drives the Dataset progress table.
--    Built from a fixed class list so every class shows even at zero, which
--    is what makes an empty class visible instead of invisible.
-- ---------------------------------------------------------------------------
create or replace view public.v_label_counts as
select
  c.label,
  count(s.id)                                      as samples,
  coalesce(round(avg(s.ppm_mean)::numeric, 4), 0)  as ppm_avg,
  coalesce(round(avg(s.ppm_sd)::numeric, 4), 0)    as ppm_sd_avg
from (values
  ('Fresh_Fish'),
  ('Formalin_6h'),('Formalin_12h'),('Formalin_24h'),
  ('Control_6h'),('Control_12h'),('Control_24h')
) as c(label)
left join public.samples s on s.label = c.label
group by c.label;

-- ---------------------------------------------------------------------------
-- 8. v_dataset_long  -  one row per capture. Use this for model training.
-- ---------------------------------------------------------------------------
create or replace view public.v_dataset_long as
select
  id, device_id, label, sample_no, n_readings,
  ppm_mean, ppm_sd, ppm_min, ppm_max, ratio_mean, rs_mean,
  baseline_ppm,
  case when baseline_ppm is not null and baseline_ppm > 0
       then round((ppm_mean / baseline_ppm)::numeric, 4)
  end as ppm_over_baseline,          -- drift-cancelled, model on this
  temp_mean, rh_mean,
  fish_species, fish_mass_g, formalin_pct, chamber_ml,
  notes, created_at
from public.samples;

-- ---------------------------------------------------------------------------
-- 9. v_dataset_wide  -  your supervisor's column layout, one row per
--    sample number. Generated on demand; never stored this way.
-- ---------------------------------------------------------------------------
create or replace view public.v_dataset_wide as
select
  sample_no,
  max(ppm_mean) filter (where label = 'Fresh_Fish')   as "Fresh_Fish",
  max(ppm_mean) filter (where label = 'Formalin_6h')  as "Formalin_Treated_Fish_6h",
  max(ppm_mean) filter (where label = 'Formalin_12h') as "Formalin_Treated_Fish_12h",
  max(ppm_mean) filter (where label = 'Formalin_24h') as "Formalin_Treated_Fish_24h"
from public.samples
group by sample_no;

-- ---------------------------------------------------------------------------
-- 10. v_dataset_raw  -  every per-second point, with its class attached.
-- ---------------------------------------------------------------------------
create or replace view public.v_dataset_raw as
select
  r.sample_id, r.label, r.sample_no, r.recorded_at, r.t_offset_ms,
  r.hcho_ppm, r.ratio, r.rs_kohm, r.adc_raw,
  s.fish_species, s.formalin_pct, s.temp_mean
from public.readings r
join public.samples s on s.id = r.sample_id;

-- ===========================================================================
--  CHECKS
-- ===========================================================================
-- Is the node alive?
--   select device_id, seq, hcho_ppm, warmed_up, is_calibrated,
--          now() - updated_at as age
--   from public.live_reading;
--
-- Class balance:
--   select * from public.v_label_counts order by label;
